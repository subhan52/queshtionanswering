import React from 'react'

export default function Navbar() {
  return (
    <div>
        <nav>
            <h1>SPOKEN QUESHTION ANSWERING SYSTEM</h1> 
        </nav>
    </div>
  )
}
